package com.huat.crud.test;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.huat.crud.bean.Department;
import com.huat.crud.bean.Employee;
import com.huat.crud.bean.EmployeeExample;
import com.huat.crud.dao.DepartmentMapper;
import com.huat.crud.dao.EmployeeMapper;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.UUID;

@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class MapperWithDeptTest {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Autowired
    private EmployeeMapper employeeMapper;

    @Test
    public void testGetEmployeeByPaginationWithDept() {
        PageHelper.startPage(1, 5);
        List<Employee> emps = employeeMapper.selectByExampleWithDept(null);
        for (Employee emp : emps) {
            System.out.println(emp);
        }
    }

    @Test
    public void testGetEmployeeByPageInfoWithDept() {
        PageHelper.startPage(10, 5);
        List<Employee> emps = employeeMapper.selectByExampleWithDept(null);
        //使用PageInfo对象包装查询到的数据,将pageInfo对象转发给页面
        //navigatePages参数表示连续显示的页数
        PageInfo pageInfo = new PageInfo(emps, 5);
        List<Employee> list = pageInfo.getList();
        for (Employee employee : list) {
            System.out.println(employee);
        }

        System.out.println("Current pageInfo: " + pageInfo.getPageNum());
        System.out.println("Total pages: " + pageInfo.getPages());
        System.out.println("Total records: " + pageInfo.getTotal());
        System.out.println("navigation pageInfo numbers: ");
        int[] nums = pageInfo.getNavigatepageNums();
        for (int i : nums) {
            System.out.print(" " + i);
        }
        System.out.println();
    }


}
