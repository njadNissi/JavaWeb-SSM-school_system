package com.huat.crud.test;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.huat.crud.bean.Department;
import com.huat.crud.bean.Employee;
import com.huat.crud.bean.EmployeeExample;
import com.huat.crud.dao.DepartmentMapper;
import com.huat.crud.dao.EmployeeMapper;
import com.huat.crud.service.DepartmentService;
import com.huat.crud.service.EmployeeService;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class MapperTest {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Autowired
    private EmployeeMapper employeeMapper;

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    @Test
    public void testCRUD() {
        System.out.println(departmentMapper);
    }

    @Test
    public void testDepartmentInsert() {
        departmentMapper.insertSelective(new Department(null, "product"));
        departmentMapper.insertSelective(new Department(null, "developer"));
        departmentMapper.insertSelective(new Department(null, "testing"));
    }

    @Test
    public void testEmployeeBatchInsert() {

//        method one
//        for(int i = 0;i<1000;i++){
//			employeeMapper.insertSelective(new Employee(null, "Jerry", "M", "Jerry@atguigu.com", 1));
//		}


//        method two
        SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);
        //注意：这里不能使用注入的EmployeeMapper，因为要使用sqlSession的批量提交，应从具有批量提交功能的sqlSession获取mapper
        //Note: Injected EmployeeMapper cannot be used here because to use batch commit of SQLSessions,
        // the mapper should be obtained from the sqlSession with batch commit capability
        EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
        for (int i = 0; i < 1000; i++) {
            String uid = UUID.randomUUID().toString().substring(0, 5) + i;
            if (i % 2 == 0) {
                mapper.insertSelective(new Employee(null, uid, "M", uid + "@163.com", 2));
            } else if (i % 3 == 0) {
                mapper.insertSelective(new Employee(null, uid, "F", uid + "@163.com", 3));
            } else {
                mapper.insertSelective(new Employee(null, uid, "M", uid + "@163.com", 1));
            }
        }
        sqlSession.clearCache();
        sqlSession.commit();
        sqlSession.close();
        System.out.println("batch finished");
    }


    @Test
    public void testGetEmployeeByExample() {
        EmployeeExample employeeExample = new EmployeeExample();
        employeeExample.or().andGenderEqualTo("F").andDIdEqualTo(3);

        List<Employee> employees = employeeMapper.selectByExample(employeeExample);
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }


    @Test
    public void testGetEmployeeCounts() {
        long count = employeeMapper.countByExample(null);
        System.out.println(count);
    }


    @Test
    public void testGetEmployeeByPagination() {
        PageHelper.startPage(1, 5);
        List<Employee> emps = employeeMapper.selectByExample(null);
        for (Employee emp : emps) {
            System.out.println(emp);
        }
    }


    @Test
    public void testGetEmployeeByPageInfo() {
        PageHelper.startPage(10, 5);
        List<Employee> emps = employeeMapper.selectByExample(null);
        //使用PageInfo对象包装查询到的数据,将pageInfo对象转发给页面
        //navigatePages参数表示连续显示的页数
        PageInfo pageInfo = new PageInfo(emps, 5);
        List<Employee> list = pageInfo.getList();
        for (Employee employee : list) {
            System.out.println(employee);
        }

        System.out.println("Current pageInfo: " + pageInfo.getPageNum());
        System.out.println("Total pages: " + pageInfo.getPages());
        System.out.println("Total records: " + pageInfo.getTotal());
        System.out.println("navigation pageInfo numbers: ");
        int[] nums = pageInfo.getNavigatepageNums();
        for (int i : nums) {
            System.out.print(" " + i);
        }
        System.out.println();
    }

    @Test
    public void testDeptBatchInsert() {

//        method two
        SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);
        //注意：这里不能使用注入的EmployeeMapper，因为要使用sqlSession的批量提交，应从具有批量提交功能的sqlSession获取mapper
        //Note: Injected EmployeeMapper cannot be used here because to use batch commit of SQLSessions,
        // the mapper should be obtained from the sqlSession with batch commit capability
        DepartmentMapper mapper = sqlSession.getMapper(DepartmentMapper.class);
        for (int i = 5; i < 50; i++) {
            String uid = UUID.randomUUID().toString().substring(0, 5) + i;
            if (i < 10) {
                mapper.insertSelective(new Department(null, "Dept00" + i));
            } else {
                mapper.insertSelective(new Department(null, "Dept0" + i));
            }
        }
        mapper.insertSelective(new Department(null, "Secretary"));
        mapper.insertSelective(new Department(null, "Research"));
        mapper.insertSelective(new Department(null, "Sales"));
        mapper.insertSelective(new Department(null, "HR"));
        sqlSession.clearCache();
        sqlSession.commit();
        sqlSession.close();
        System.out.println("batch finished");
    }

    @Test
    public void deleteDepartment(){
        String ids = "2006,2007";

        if (ids.contains(",")) {// 1,2
            //批量删除
            String[] str_ids = ids.split(",");
           // List<Integer> int_ids = new ArrayList<>();
            for (String id : str_ids) {
                int int_id = Integer.parseInt(id);
                int empNo = employeeMapper.getNumOfEmployeesByDeptId(int_id);
                if(empNo == 0)
                    departmentMapper.deleteByPrimaryKey(int_id);
            }
        } else {
            //单个删除
            departmentMapper.deleteByPrimaryKey(Integer.parseInt(ids));
        }
    }

}
