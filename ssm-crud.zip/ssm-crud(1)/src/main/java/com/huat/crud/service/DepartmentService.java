package com.huat.crud.service;

import com.huat.crud.bean.Department;
import com.huat.crud.bean.DepartmentExample;
import com.huat.crud.bean.Employee;
import com.huat.crud.bean.EmployeeExample;
import com.huat.crud.dao.DepartmentMapper;
import com.huat.crud.dao.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class DepartmentService {
    @Autowired
    private DepartmentMapper departmentMapper;


    public List<Department> getAll() {
        return departmentMapper.selectByExample(null);
    }
    public void addDept(Department department) {
        departmentMapper.insertSelective(department);
    }

    public long checkname(String depName) {
        DepartmentExample example = new DepartmentExample();
        example.or().andDeptNameEqualTo(depName);
        return departmentMapper.countByExample(example);
    }
    public Department getDept(Integer id) {
        return departmentMapper.selectByPrimaryKey(id);
    }
    public void updateDept(Department department) {
        departmentMapper.updateByPrimaryKeySelective(department);
    }
    public void deleteDept(Integer id) {
        departmentMapper.deleteByPrimaryKey(id);
    }

    public void deleteBatchDept(List<Integer> ids) {
        DepartmentExample example = new DepartmentExample();
        example.or().andDeptIdIn(ids);
        departmentMapper.deleteByExample(example);
    }
    public List<Department> searchDept(String deptName) {
        DepartmentExample example = new DepartmentExample();
        if (!deptName.isEmpty()) {
            example.or().andDeptNameLike("%" + deptName + "%");
        }
        return departmentMapper.selectByExample(example);
    }
}