package com.huat.crud.service;

import com.huat.crud.bean.Employee;
import com.huat.crud.bean.EmployeeExample;
import com.huat.crud.dao.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeMapper employeeMapper;

    public List<Employee> getAll() {
        return employeeMapper.selectByExampleWithDept(null);
    }
    public void addEmployee(Employee employee) {
        employeeMapper.insertSelective(employee);
    }

    public long checkname(String empName) {
        EmployeeExample example = new EmployeeExample();
        example.or().andEmpNameEqualTo(empName);
        return employeeMapper.countByExample(example);
    }
    public Employee getEmp(Integer id) {
        Employee employee = employeeMapper.selectByPrimaryKeyWithDept(id);
        return employee;
    }
    public void updateEmp(Employee employee) {
        employeeMapper.updateByPrimaryKeySelective(employee);
    }
    public void deleteEmp(Integer id) {
        employeeMapper.deleteByPrimaryKey(id);
    }
    public void deleteBatchEmp(List<Integer> ids) {
        EmployeeExample example = new EmployeeExample();
        example.or().andEmpIdIn(ids);
        employeeMapper.deleteByExample(example);
    }
    public List<Employee> searchEmp(String empName) {
        EmployeeExample example = new EmployeeExample();
        if (!empName.isEmpty()) {
            example.or().andEmpNameLike("%" + empName + "%");
        }
        return employeeMapper.selectByExampleWithDept(example);
    }

    public int getNumOfEmployeesByDeptId(Integer deptId){
        return employeeMapper.getNumOfEmployeesByDeptId(deptId);
    }
}
