package com.huat.crud.controller;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.huat.crud.bean.Department;
import com.huat.crud.bean.Employee;
import com.huat.crud.service.DepartmentService;
import com.huat.crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/emp")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private DepartmentService departmentService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String getAllEmps(@RequestParam(value = "pn", defaultValue = "1") Integer pn, Model model) {
        PageHelper.startPage(pn, 7);
        List<Employee> employeeList = employeeService.getAll();
        List<Department> departments = departmentService.getAll();
        //使用PageInfo对象包装查询到的数据,将pageInfo对象转发给页面
        //navigatePages参数表示连续显示的页数
        PageInfo pageInfo = new PageInfo(employeeList, 5);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("departments", departments);
        return "employee";
    }
    @RequestMapping(value = "add", method = RequestMethod.GET)
    public String toAddEmp(Model model) {
        List<Department> departments = departmentService.getAll();
        model.addAttribute("departments", departments);
        return "employee_add";
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public String addEmp(Employee employee) {
        System.out.println(employee);
        employeeService.addEmployee(employee);
        return "redirect:/emp";
    }

    @RequestMapping(value = "checkname", method = RequestMethod.GET)
    @ResponseBody
    public String checkname(String empName) {
        long n = employeeService.checkname(empName);
        return n > 0 ? "{\"getdata\":\"false\"}" : "{\"getdata\":\"true\"}";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public String getEmp(@PathVariable("id") Integer id, Model model) {
        Employee employee = employeeService.getEmp(id);
        List<Department> departments = departmentService.getAll();
        model.addAttribute("employee", employee);
        model.addAttribute("departments", departments);
        return "employee_update";
    }

    @RequestMapping(value = "", method = RequestMethod.PUT)
    public String saveEmp(Employee employee) {
        employeeService.updateEmp(employee);
        return "redirect:/emp";
    }

//    single record delete
//    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
//    public String deleteEmp(@PathVariable("id") Integer id) {
//        employeeService.deleteEmp(id);
//        return "redirect:/emp";
//    }

    @RequestMapping(value = "/{ids}", method = RequestMethod.DELETE)
    public String deleteEmp(@PathVariable("ids") String ids) {
        if (ids.contains(",")) {// 1,2
            //批量删除
            String[] str_ids = ids.split(",");
            List<Integer> int_ids = new ArrayList<>();
            for (String id : str_ids) {
                int_ids.add(Integer.parseInt(id));
            }
            employeeService.deleteBatchEmp(int_ids);
        } else {
            //单个删除
            employeeService.deleteEmp(Integer.parseInt(ids));

        }
        return "redirect:/emp";
    }
    @RequestMapping(value = "search", method = RequestMethod.POST)
    public String searchEmp(String empName, Model model) {
        PageHelper.startPage(1, 7);
        List<Employee> emps = employeeService.searchEmp(empName);
        PageInfo pageInfo = new PageInfo(emps);
        model.addAttribute("pageInfo", pageInfo);
        return "employee";
    }

}