package com.huat.crud.controller;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.huat.crud.bean.Department;
import com.huat.crud.service.DepartmentService;
import com.huat.crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/dept")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @Autowired EmployeeService employeeService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String getAllDepts(@RequestParam(value = "pn", defaultValue = "1") Integer pn, Model model) {
        PageHelper.startPage(pn, 7);
        List<Department> departments = departmentService.getAll();
        //使用PageInfo对象包装查询到的数据,将pageInfo对象转发给页面
        //navigatePages参数表示连续显示的页数
        PageInfo pageInfo = new PageInfo(departments, 5);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("departments", departments);
        return "department";
    }
    @RequestMapping(value = "add", method = RequestMethod.GET)
    public String toAddDept(Model model) {
        List<Department> departments = departmentService.getAll();
        model.addAttribute("departments", departments);
        return "department_add";
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public String addDept(Department department) {
        System.out.println(department);
        departmentService.addDept(department);
        return "redirect:/dept";
    }

    @RequestMapping(value = "checkname", method = RequestMethod.GET)
    @ResponseBody
    public String checkname(String deptName) {
        long n = departmentService.checkname(deptName);
        return n > 0 ? "{\"getdata\":\"false\"}" : "{\"getdata\":\"true\"}";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public String getEmp(@PathVariable("id") Integer id, Model model) {
        Department department = departmentService.getDept(id);
        List<Department> departments = departmentService.getAll();
        model.addAttribute("department", department);
        model.addAttribute("departments", departments);
        return "department_update";
    }

    @RequestMapping(value = "", method = RequestMethod.PUT)
    public String saveEmp(Department department) {
        departmentService.updateDept(department);
        return "redirect:/dept";
    }

    @RequestMapping(value = "/{ids}", method = RequestMethod.DELETE)
    public String deleteDept(@PathVariable("ids") String ids) {

        System.out.println("Here Here Here Here Here");

        if (ids.contains(",")) {// 1,2
            //批量删除
            String[] str_ids = ids.split(",");
            List<Integer> int_ids = new ArrayList<>();
            for (String id : str_ids) {
                int int_id = Integer.parseInt(id);
                int empNo = employeeService.getNumOfEmployeesByDeptId(int_id);
                if(empNo == 0)
                    int_ids.add(int_id);
                else
                    System.out.println("DeptId = " + id + " cannot be deleted because it has " + empNo + " employees!");
            }

            departmentService.deleteBatchDept(int_ids);
        } else {
            //单个删除
            departmentService.deleteDept(Integer.parseInt(ids));
        }
        return "redirect:/dept";
    }
    @RequestMapping(value = "search", method = RequestMethod.POST)
    public String searchEmp(String deptName, Model model) {
        PageHelper.startPage(1, 7);
        List<Department> departments = departmentService.searchDept(deptName);
        PageInfo pageInfo = new PageInfo(departments);
        model.addAttribute("pageInfo", pageInfo);
        return "department";
    }

}